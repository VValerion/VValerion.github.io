const http = require('http');

const apiOptions = {
  server: 'localhost',
  port: 3000,
  path: '/api/trips',
  method: 'GET'
};

const renderTravelPage = (req, res, responseBody) => {
  let message = null;

  if (!(responseBody instanceof Array)) {
    message = 'API lookup error';
    responseBody = [];
  } else if (!responseBody.length) {
    message = 'No trips found';
  }

  res.render('travel', {
    title: 'Travlr Getaways',
    trips: responseBody,
    message
  });
};

const requestTrips = (req, res) => {
  const requestOptions = {
    host: apiOptions.server,
    port: apiOptions.port,
    path: apiOptions.path,
    method: apiOptions.method
  };

  const apiRequest = http.request(requestOptions, (apiResponse) => {
    let responseBody = '';

    apiResponse.on('data', (chunk) => {
      responseBody += chunk;
    });

    apiResponse.on('end', () => {
      try {
        renderTravelPage(req, res, JSON.parse(responseBody));
      } catch (err) {
        res.status(500).render('travel', {
          title: 'Travlr Getaways',
          trips: [],
          message: 'Error parsing API response'
        });
      }
    });
  });

  apiRequest.on('error', () => {
    res.status(500).render('travel', {
      title: 'Travlr Getaways',
      trips: [],
      message: 'Error connecting to the API'
    });
  });

  apiRequest.end();
};

module.exports = {
  travel: requestTrips
};
