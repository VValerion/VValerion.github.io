CS 465 Module Seven Security Testing Notes

This update adds login authentication to the Travlr admin SPA and secures the admin trip endpoints with bearer token authentication.

Admin login for testing:
Email: admin@travlr.com
Password: password

Before testing login, create the test user:
npm run seed:user

Run the Express/MongoDB API:
npm start

Run the Angular admin app from the app_admin folder:
npm start

Postman tests:
1. POST http://localhost:3000/api/register
Body:
{
  "name": "Travlr Admin",
  "email": "admin@travlr.com",
  "password": "password"
}
Expected: 200 response with token.

2. POST http://localhost:3000/api/login
Body:
{
  "email": "admin@travlr.com",
  "password": "password"
}
Expected: 200 response with token.

3. Try POST, PUT, or DELETE /api/trips without a token.
Expected: 401 unauthorized.

4. Try POST, PUT, or DELETE /api/trips with Authorization header:
Bearer <token from login>
Expected: request is allowed.

Front-end test:
1. Open the admin SPA.
2. Confirm it redirects to /login.
3. Log in with admin@travlr.com and password.
4. Confirm Trips and Add Trip appear in the navigation.
5. Add, edit, and delete a trip after login.
6. Click Logout and confirm admin routes are protected again.
