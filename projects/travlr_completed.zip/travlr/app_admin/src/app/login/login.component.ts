import { Component } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { NgIf } from '@angular/common';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, NgIf, RouterLink],
  templateUrl: './login.component.html'
})
export class LoginComponent {
  message = '';

  loginForm = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', Validators.required]
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  login(): void {
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      this.message = 'Please enter an email and password.';
      return;
    }

    const credentials = {
      email: this.loginForm.controls.email.value || '',
      password: this.loginForm.controls.password.value || ''
    };

    this.authenticationService.login(credentials).subscribe({
      next: () => this.router.navigate(['/trips']),
      error: () => this.message = 'Login failed. Check the email and password.'
    });
  }
}
