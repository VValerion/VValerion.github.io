import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { NgIf } from '@angular/common';
import { AuthenticationService } from './services/authentication.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, NgIf],
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'Travlr Getaways Admin';

  constructor(public authenticationService: AuthenticationService) {}

  logout(): void {
    this.authenticationService.logout();
  }
}
