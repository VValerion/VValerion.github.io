import { Component, OnInit } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { NgIf } from '@angular/common';
import { TripDataService } from '../../services/trip-data.service';
import { Trip } from '../trip';

@Component({
  selector: 'app-trip-edit',
  standalone: true,
  imports: [ReactiveFormsModule, NgIf, RouterLink],
  templateUrl: './trip-edit.component.html'
})
export class TripEditComponent implements OnInit {
  originalCode = '';
  isEditMode = false;
  message = '';

  tripForm = this.fb.group({
    code: ['', Validators.required],
    name: ['', Validators.required],
    length: ['', Validators.required],
    start: ['', Validators.required],
    resort: ['', Validators.required],
    perPerson: ['', Validators.required],
    image: ['', Validators.required],
    description: ['', Validators.required]
  });

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private tripDataService: TripDataService
  ) {}

  ngOnInit(): void {
    const code = this.route.snapshot.paramMap.get('code');

    if (code) {
      this.originalCode = code;
      this.isEditMode = true;
      this.tripDataService.getTrip(code).subscribe({
        next: (trip) => this.tripForm.patchValue({
          ...trip,
          start: this.formatDateForInput(trip.start)
        }),
        error: () => this.message = 'Unable to load this trip.'
      });
    }
  }

  saveTrip(): void {
    if (this.tripForm.invalid) {
      this.tripForm.markAllAsTouched();
      this.message = 'Please complete all trip fields before saving.';
      return;
    }

    const trip = this.tripForm.getRawValue() as Trip;

    if (this.isEditMode) {
      this.tripDataService.updateTrip(this.originalCode, trip).subscribe({
        next: () => {
          this.message = 'Trip updated successfully.';
          this.router.navigate(['/trips']);
        },
        error: () => this.message = 'Unable to update trip.'
      });
    } else {
      this.tripDataService.addTrip(trip).subscribe({
        next: () => {
          this.message = 'Trip added successfully.';
          this.router.navigate(['/trips']);
        },
        error: () => this.message = 'Unable to add trip.'
      });
    }
  }

  private formatDateForInput(value: string): string {
    if (!value) {
      return '';
    }

    return new Date(value).toISOString().substring(0, 10);
  }
}
