import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NgFor, NgIf } from '@angular/common';
import { TripDataService } from '../../services/trip-data.service';
import { Trip } from '../trip';
import { TripCardComponent } from '../trip-card/trip-card.component';

@Component({
  selector: 'app-trip-list',
  standalone: true,
  imports: [NgFor, NgIf, RouterLink, TripCardComponent],
  templateUrl: './trip-list.component.html'
})
export class TripListComponent implements OnInit {
  trips: Trip[] = [];
  message = '';
  loading = false;

  constructor(private tripDataService: TripDataService) {}

  ngOnInit(): void {
    this.loadTrips();
  }

  loadTrips(): void {
    this.loading = true;
    this.tripDataService.getTrips().subscribe({
      next: (trips) => {
        this.trips = trips;
        this.loading = false;
      },
      error: () => {
        this.message = 'Unable to load trips from the API.';
        this.loading = false;
      }
    });
  }

  deleteTrip(code: string): void {
    this.tripDataService.deleteTrip(code).subscribe({
      next: () => {
        this.trips = this.trips.filter((trip) => trip.code !== code);
        this.message = 'Trip deleted successfully.';
      },
      error: () => {
        this.message = 'Unable to delete trip.';
      }
    });
  }
}
