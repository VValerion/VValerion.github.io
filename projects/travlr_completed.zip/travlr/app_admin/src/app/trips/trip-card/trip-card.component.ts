import { Component, EventEmitter, Input, Output } from '@angular/core';
import { RouterLink } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Trip } from '../trip';

@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [RouterLink, DatePipe],
  templateUrl: './trip-card.component.html'
})
export class TripCardComponent {
  @Input({ required: true }) trip!: Trip;
  @Output() deleteTrip = new EventEmitter<string>();

  imagePath(): string {
    return `http://localhost:3000/images/${this.trip.image}`;
  }

  confirmDelete(): void {
    if (confirm(`Delete ${this.trip.name}?`)) {
      this.deleteTrip.emit(this.trip.code);
    }
  }
}
