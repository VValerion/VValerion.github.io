CS 465 Module Six testing notes

What was updated
1. Added backend REST API methods for trips.
   GET /api/trips
   POST /api/trips
   GET /api/trips/:tripCode
   PUT /api/trips/:tripCode
   DELETE /api/trips/:tripCode

2. Added an Angular admin SPA in app_admin.
   Trip list component displays trip cards.
   Trip card component holds reusable trip card UI.
   Trip edit component supports adding and editing trips.
   Trip data service makes GET, POST, PUT, and DELETE API requests.

How to run the Express backend
1. Open a terminal in the main travlr folder.
2. Start MongoDB.
3. Run npm install if needed.
4. Run npm run seed if the database needs sample trips.
5. Run npm start.
6. Open http://localhost:3000/travel to see the public Express travel page.

How to run the Angular admin SPA
1. Open a second terminal in travlr/app_admin.
2. Run npm install.
3. Run npm start.
4. Open http://localhost:4200.

What screenshots to submit
1. Card listing showing an added trip in the Angular admin page.
2. Edit screen showing a selected trip loaded into the edit form.
3. Update screen after changing and saving a trip.

Postman checks
GET http://localhost:3000/api/trips
POST http://localhost:3000/api/trips
PUT http://localhost:3000/api/trips/GALR210214
DELETE http://localhost:3000/api/trips/GALR210214

Sample POST body
{
  "code": "TEST260614",
  "name": "Module Six Test Trip",
  "length": "3 nights / 4 days",
  "start": "2026-07-15",
  "resort": "Travlr Beach Resort",
  "perPerson": "899.00",
  "image": "reef1.jpg",
  "description": "A test trip added through the Module Six Angular admin SPA."
}
