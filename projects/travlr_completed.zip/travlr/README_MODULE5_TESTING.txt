CS 465 Module Five testing notes

1. Open this folder in Visual Studio Code.
2. Start MongoDB locally.
3. Run npm install.
4. Optional, but recommended if the database is empty: run npm run seed.
5. Run npm start.
6. Test these routes in Postman or a browser:
   GET http://localhost:3000/api/trips
   GET http://localhost:3000/api/trips/GALR210214
   GET http://localhost:3000/api/trips/DAWR210315
   GET http://localhost:3000/api/trips/CLAR210621
   GET http://localhost:3000/api/trips/BADCODE
7. Expected results:
   /api/trips returns an array of all trips with HTTP 200.
   /api/trips/GALR210214 returns one trip with HTTP 200.
   /api/trips/BADCODE returns HTTP 404 with a JSON error message.
8. The customer travel page is refactored to request trip data from the REST API:
   http://localhost:3000/travel
