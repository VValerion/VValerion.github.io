const crypto = require('crypto');

const jwtSecret = process.env.JWT_SECRET || 'travlrModuleSevenSecret';

const sendUnauthorized = (res) => {
  res.status(401).json({ message: 'Unauthorized: authentication token is required' });
};

const timingSafeEquals = (first, second) => {
  const firstBuffer = Buffer.from(first);
  const secondBuffer = Buffer.from(second);

  if (firstBuffer.length !== secondBuffer.length) {
    return false;
  }

  return crypto.timingSafeEqual(firstBuffer, secondBuffer);
};

const verifyToken = (token) => {
  try {
    const parts = token.split('.');

    if (parts.length !== 3) {
      return null;
    }

    const [header, payload, signature] = parts;
    const expectedSignature = crypto
      .createHmac('sha256', jwtSecret)
      .update(`${header}.${payload}`)
      .digest('base64url');

    if (!timingSafeEquals(signature, expectedSignature)) {
      return null;
    }

    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));

    if (decoded.exp && decoded.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }

    return decoded;
  } catch (err) {
    return null;
  }
};

const auth = (req, res, next) => {
  const authorization = req.headers.authorization;

  if (!authorization || !authorization.startsWith('Bearer ')) {
    sendUnauthorized(res);
    return;
  }

  const token = authorization.split(' ')[1];
  const decoded = verifyToken(token);

  if (!decoded) {
    sendUnauthorized(res);
    return;
  }

  req.auth = decoded;
  next();
};

module.exports = auth;
