const mongoose = require('mongoose');
const User = mongoose.model('users');

const sendJsonResponse = (res, status, content) => {
  res.status(status).json(content);
};

const register = async (req, res) => {
  if (!req.body.name || !req.body.email || !req.body.password) {
    sendJsonResponse(res, 400, { message: 'All fields are required' });
    return;
  }

  try {
    const user = new User();
    user.name = req.body.name;
    user.email = req.body.email.trim().toLowerCase();
    user.setPassword(req.body.password);

    await user.save();

    sendJsonResponse(res, 200, {
      token: user.generateJwt()
    });
  } catch (err) {
    sendJsonResponse(res, 400, {
      message: 'Unable to register user',
      error: err.message
    });
  }
};

const login = async (req, res) => {
  if (!req.body.email || !req.body.password) {
    sendJsonResponse(res, 400, { message: 'All fields are required' });
    return;
  }

  try {
    const user = await User.findOne({ email: req.body.email.trim().toLowerCase() }).exec();

    if (!user || !user.validPassword(req.body.password)) {
      sendJsonResponse(res, 401, { message: 'Invalid email or password' });
      return;
    }

    sendJsonResponse(res, 200, {
      token: user.generateJwt()
    });
  } catch (err) {
    sendJsonResponse(res, 500, {
      message: 'Login failed',
      error: err.message
    });
  }
};

module.exports = {
  register,
  login
};
