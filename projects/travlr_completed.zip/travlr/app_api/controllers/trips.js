const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

const requiredTripFields = ['code', 'name', 'length', 'start', 'resort', 'perPerson', 'image', 'description'];

const sendJsonResponse = (res, status, content) => {
  res.status(status).json(content);
};

const buildTripPayload = (body) => ({
  code: body.code ? body.code.trim().toUpperCase() : undefined,
  name: body.name ? body.name.trim() : undefined,
  length: body.length ? body.length.trim() : undefined,
  start: body.start,
  resort: body.resort ? body.resort.trim() : undefined,
  perPerson: body.perPerson ? body.perPerson.toString().trim() : undefined,
  image: body.image ? body.image.trim() : undefined,
  description: body.description ? body.description.trim() : undefined
});

const validateTripPayload = (payload) => requiredTripFields.filter((field) => !payload[field]);

const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).sort({ start: 1 }).exec();
    sendJsonResponse(res, 200, trips);
  } catch (err) {
    sendJsonResponse(res, 500, {
      message: 'Error retrieving trips',
      error: err.message
    });
  }
};

const tripsFindByCode = async (req, res) => {
  const tripCode = req.params.tripCode ? req.params.tripCode.trim().toUpperCase() : '';

  if (!tripCode) {
    sendJsonResponse(res, 400, { message: 'Trip code is required' });
    return;
  }

  try {
    const trip = await Trip.findOne({ code: tripCode }).exec();

    if (!trip) {
      sendJsonResponse(res, 404, {
        message: `Trip code ${tripCode} was not found`
      });
      return;
    }

    sendJsonResponse(res, 200, trip);
  } catch (err) {
    sendJsonResponse(res, 500, {
      message: 'Error retrieving trip',
      error: err.message
    });
  }
};

const tripsAddTrip = async (req, res) => {
  const payload = buildTripPayload(req.body);
  const missingFields = validateTripPayload(payload);

  if (missingFields.length) {
    sendJsonResponse(res, 400, { message: `Missing required fields: ${missingFields.join(', ')}` });
    return;
  }

  try {
    const newTrip = await Trip.create(payload);
    sendJsonResponse(res, 201, newTrip);
  } catch (err) {
    sendJsonResponse(res, 400, {
      message: 'Error adding trip',
      error: err.message
    });
  }
};

const tripsUpdateTrip = async (req, res) => {
  const tripCode = req.params.tripCode ? req.params.tripCode.trim().toUpperCase() : '';

  if (!tripCode) {
    sendJsonResponse(res, 400, { message: 'Trip code is required' });
    return;
  }

  const payload = buildTripPayload(req.body);
  const missingFields = validateTripPayload(payload);

  if (missingFields.length) {
    sendJsonResponse(res, 400, { message: `Missing required fields: ${missingFields.join(', ')}` });
    return;
  }

  try {
    const updatedTrip = await Trip.findOneAndUpdate(
      { code: tripCode },
      payload,
      { new: true, runValidators: true }
    ).exec();

    if (!updatedTrip) {
      sendJsonResponse(res, 404, {
        message: `Trip code ${tripCode} was not found`
      });
      return;
    }

    sendJsonResponse(res, 200, updatedTrip);
  } catch (err) {
    sendJsonResponse(res, 400, {
      message: 'Error updating trip',
      error: err.message
    });
  }
};

const tripsDeleteTrip = async (req, res) => {
  const tripCode = req.params.tripCode ? req.params.tripCode.trim().toUpperCase() : '';

  if (!tripCode) {
    sendJsonResponse(res, 400, { message: 'Trip code is required' });
    return;
  }

  try {
    const deletedTrip = await Trip.findOneAndDelete({ code: tripCode }).exec();

    if (!deletedTrip) {
      sendJsonResponse(res, 404, {
        message: `Trip code ${tripCode} was not found`
      });
      return;
    }

    res.status(204).send();
  } catch (err) {
    sendJsonResponse(res, 500, {
      message: 'Error deleting trip',
      error: err.message
    });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};
