const mongoose = require('mongoose');
const trips = require('../../app_server/data/trips.json');
require('../models/travlr');

const dbURI = 'mongodb://127.0.0.1/travlr';
const Trip = mongoose.model('trips');

const seedTrips = async () => {
  try {
    await mongoose.connect(dbURI);
    await Trip.deleteMany({});
    await Trip.insertMany(trips);
    console.log(`Inserted ${trips.length} trips into the travlr database.`);
  } catch (err) {
    console.error('Error seeding trips:', err);
  } finally {
    await mongoose.connection.close();
  }
};

seedTrips();
