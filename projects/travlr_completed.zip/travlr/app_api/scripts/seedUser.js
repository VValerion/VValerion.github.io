require('../models/db');
const mongoose = require('mongoose');
const User = mongoose.model('users');

const seedUser = async () => {
  const email = 'admin@travlr.com';
  const password = 'password';

  try {
    await User.deleteOne({ email }).exec();

    const user = new User();
    user.name = 'Travlr Admin';
    user.email = email;
    user.setPassword(password);

    await user.save();
    console.log('Admin user created.');
    console.log(`Email: ${email}`);
    console.log(`Password: ${password}`);
  } catch (err) {
    console.error('Unable to seed admin user:', err.message);
  } finally {
    mongoose.connection.close();
  }
};

seedUser();
